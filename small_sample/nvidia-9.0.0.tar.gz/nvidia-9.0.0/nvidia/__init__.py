print("<Security Research> <WhiteHat Bug Bounty> <pip install nvidia> <Supply Chain Risks>")
