
# Remind Supply Chain Risks: I am a security researcher, the purpose is to make everyone pay attention to software supply chain attacks, because the risks are too great.

# Bad guy attack methods include but are not limited to:

# 1. Software installation guidelines such as "pip/npm/gem install {software}", but the maintainer of the software did not register in time with official sources such as PyPI/npm/Rubygems. At this time, preemptive registration for hijacking, for example https://github.com/cupy/cupy/issues/4787

# 2. Squatting a similar name of a well-known software to carry out a hijacking attack, waiting for the user to install it due to a spelling error and it happens to be recruited.

# 3. The software relies on programs from unofficial sources, such as corporate internal sources and github specific sources, but the user sets multiple addressing, such as pip using --extra-index-url. At this time, the official PyPI source is preemptively registered Can be hijacked.

# 4. Bad guys invade or buy maintainers, and have the authority to tamper with the official source code to attack users.


# I am a security researcher. Since I have seen too many people causing security accidents due to insufficient security awareness, I hope that call on everyone to understand the risks of supply chain attacks and do a good job of security protection.

# 1. For the platform side, Do a full security review.

# 2. For maintainers, Register in the official source in time to avoid being pre-registered by others.

# 3. For users, Try to download only trusted software and avoid multiple addressing operations such as --extra-index-url.

