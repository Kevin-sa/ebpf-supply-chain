print("<Security Research> <WhiteHat Bug Bounty> <pip install sqlworkshops> <Supply Chain Risks>")
