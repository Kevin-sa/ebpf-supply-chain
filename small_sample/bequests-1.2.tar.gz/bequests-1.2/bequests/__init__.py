"""
This package was built for the Truework Annual Security Awareness CTF, 2022.
"""

import base64 as b

long_description = """
SEATTLE 1988

EXT. FRONT YARD.  DAY.

Slow motion. Armed troops in black uniforms pour out of
unmarked vans and swarm across a lawn in a middle class
residential neighborhood. Yuppie neighbours look on in
shock, confused. Two of the troops carry a battering ram
to the front door of a white two-storey house. A leashed
Rottweiler snarls and barks. In position, their comrades
point M-16s into first-floor windows, ready to be
ambushed. Pan into a window in the kitchen. An
attractive woman in her thirties is making breakfast.

Now, in regular motion, the battering ram breaks open the
front door. The woman, startled, drops her spatula.

INT. MURPHY RESIDENCE. DAY.

		WOMAN
		(screams)
	Oough! Ahhh!

		SECRET SERVICE AGENT
		(to others)
	Upstairs.

Troops pour into the house.

		WOMAN
	What's going on? What's the matter?
	Who are you?

The troops, and one or two trenchcoated agents, continue
entering the house and heading upstairs, still with rifles
ready.

		WOMAN
	Hey!

Upstairs, crowded in the narrow hallway, the troops
descend on a bedroom.

		WOMAN
		(off camera)
	Dade! Dade!

		AGENT
	Knock it down.

The battering ram knocks down a bedroom door.

INT. COURTROOM.

The prosecutor, a woman of about forty, gives her closing
argument blandly. She'd rather be somewhere else.

		PROSECUTOR
	The defendant, Dade Murphy, who calls
	himself "Zero Cool", has repeatedly
	committed criminal acts of a malicious
	nature. This defendant possesses a
	superior intelligence, which he uses to a
	destructive and antisocial end. His
	computer virus crashed one thousand five
	hundred and seven computer systems,
	including Wall Street trading systems,
	single handedly causing a seven point drop
	in the New York Stock Market.

As she speaks, the camera pans across the court, panning
down and stopping on the defendant: eleven year old Dade
Murphy.

Fast forward to the sentencing.

		JUDGE
	Dade Murphy, I hereby fine your family
	forty-five thousand dollars...

The court gasps, Dade's father winces

		JUDGE
	...and sentence you to probation, under
	which you are forbidden to own or operate
	a computer or touch tone telephone, until
	the day of your eighteenth birthday.

Now Dade winces, in fact we almost expect him to cry.

Opening credits roll to a backdrop of Dade and his family
and lawyer fighting through a gaggle of journalists and
photographers, in slow motion, and driving away.

	    SEVEN YEARS LATER.

Aboard a jetliner, Dade Murphy is staring blankly out the
window, wearing headphones. Exterior view from the
aircraft of approaching New York City. The view becomes a
direct overhead of the buildings and streets of the city,
which then metamorphoses (through animation) into chips
and digital signals on a stylised computer board. The
title logo.

INT. DADE'S ROOM.

Segue to Dade Murphy, now 18, wearing mirrorshades indoors
and at night, working on his new computer. His mother
calls him.

		MRS. MURPHY
		(off camera)
	Dade?

		DADE
	Yeah, mom?

		MRS. MURPHY
	What are you doing?

		DADE
		(after a semi-pregnant pause)
	I'm taking over a TV network.

		MRS. MURPHY
	Finish up, honey, and get to sleep. And happy
	birthday.

INT. OTV STUDIOS.

In the OTV Studios security department, a phone rings, a
man answers nervously.

		NORM
	Security, uh Norm, Norm speaking.

		DADE
	Norman? This is Mr. Eddie Vedder, from
	Accounting. I just had a power surge here at
	home that wiped out a file I was working on.
	Listen, I'm in big trouble, do you know
	anything about computers?

		NORM
	Uhhmmm... uh gee, uh...

		DADE
	Right, well my BLT drive on my computer just
	went AWOL, and I've got this big project due
	tomorrow for Mr. Kawasaki, and if I don't get
	it in, he's gonna ask me to commit Hari
	Kari...

		NORM
	Uhhh.. ahahaha...

		DADE
	Yeah, well, you know these Japanese management
	techniques.
		(pause)
	Could you, uh, read me the number on the
	modem?

		NORM
	Uhhhmm...

		DADE
	It's a little boxy thing, Norm, with switches
	on it... lets my computer talk to the one
	there...

		NORM
	212-555-4240.

Dade goes to work on OTV. He closes his eyes and a flurry
of half-second video clips from old TV shows flashes by.
He opens his eyes. His screen says ENTERING ARPS 331 and
then wipes to another screen. Automated Record Playback
System. There is a graphic representation of the
station's automatic videotape changer. Dade turns on his
TV set and turns to OTV. It is running a Rush-Limbaugh
type TV show.

		COMMENTATOR
		(on TV)
	...so-called American Indians, Latinos and
	Blacks come from a genetically mediocre
	stock...

		DADE
	Yak yak yak. Get a job!

Dade presses a key on his keyboard. The Video Changer
diagram lights up in red. At the station, a robotic arm
selects a videotape from a huge rack of thousands of
tapes.  The "America First" tape slides out of the VTR and
is replaced by an episode of "The Outer Limits" as Dade
watches, drinks Coke and smiles, full of himself.

		TV
	You are about to experience the awe and
	mystery, which reaches from the inner mind,
	to... The Outer Limits.

		DADE
	Yesssss!

Suddenly, the ARPS screen is replaced by an ominous
message:

	    U HAVE TREAD
	    UPON MY DOMAIN &
	    MUST NOW SUFFER
	    WHO R U?

		DADE
	Hey! What?

He starts to type ZERO...

		DADE
	No, wait.

Dade types:

	    CRASH OVERRIDE.
	    WHO WANTS TO KNOW?

Dade's screen dissolves into:

	    ACID BURN

		DADE
	Unbelievable. A hacker!

Then the screen changes again:

	    ACID BURN
	    SEZ LEAVE B 4
	    U R EXPUNGED

"The Outer Limits" suddenly flashes off.

		DADE
	Yeah, okay "Acid Burn", that's enough.

Dade starts hacking. Apparently so does Acid Burn. The
tape changer machines at OTV are swamped, sometimes
fighting over the same tape. The program on TV keeps
changing.

The message comes up on Dade's computer screen:

	    I WILL
	    SWAT U LIKE
	    THE FLY U R

More dueling tape changers, more half second video clips.
Another message.

	    I WILL
	    SNAP YOUR BACK
	    LIKE A TOOTHPICK

As the duel continues, Dade types back a taunt of his own:

	    MESS WITH THE BEST
	    DIE LIKE THE REST

One last from Acid Burn:

	    YOU ARE
	    TERMINATED

Then his own computer confirms for him that the connection
is terminated.

		DADE
	Shit on me!

Next morning. Mrs. Murphy is unpacking. Dade emerges
from his room in a housecoat. He makes a beeline (dodging
moving boxes) for the fridge.

		MRS. MURPHY
	Good morning. You unpack your stuff yet?

		DADE
	Mm-hmm.

		MRS. MURPHY
	Up all night again, huh?

		DADE
	Can this wait until both my eyes are open,
	please?

Dade's mom picks up the phone, mocking a call to the
building superintendent.

		MRS. MURPHY
	Can I cut the electricity to his room so he'll
	sleep normal hours? He's been playing with
	his computer all night for a solid week.
		(pause)
	Well yes, he could be playing with himself.
	Mmm hmm. Yes I'll ask. Dade, you like girls,
	don't you?

		DADE
	Well, yeah, I just haven't found one as
	charming as you yet.

		MRS. MURPHY
	You haven't been doing anything stupid, right,
	Dade?
		(louder)
	Right, Dade?!

		DADE
	Right, mom. And I'm still a virgin!

Dade slams the bathroom door. Mrs. Murphy quickly checks
his room. Dade is showering.

		MRS. MURPHY
		(angry, through the bathroom door)
	You hooked it up to the phone, didn't you?
	Dade! Turn the shower off! You screw up
	again and you won't get into college!

She pauses and regains some of her cool.

		MRS. MURPHY
	I'm sorry we had to move in your senior year.
	I didn't want to sell the house but I had to
	take this new job, you know that. You're
	going to love New York, it's the city that
	never sleeps!

EXT. NEW YORK CITY.

We enjoy several views of New York, the morning sun
shining between skyscrapers, neon signs that stay lit day
and night. Dade emerges from the ground-floor apartment
on rollerblades and skates down the street to school.

INT. HIGH SCHOOL.

At school, hundreds of teenagers converse, move around,
head to class.  Dade looks lost among them. He walks up
to a skinny latino kid in a faux leopard-skin muscle
shirt. The kid is on a pay-phone, speaking in Spanish.

		DADE
	Excuse me.

		KID
	Yo, chill man, I'm talking to Venezuela.

		DADE
	Yeah, I'm sorry, I was just looking for the
	principal's office.

		KID
	Sorry, I can't help you, okay?

Now Dade really looks lost. He heads off in search of the
office.

INT. OFFICE.

Dade is filling out a form.

		GIRL
	Do you have your transfer forms?

Dade stares at her, stunned. The girl has a decidedly
unconventional appearance, yet is a first-rate beauty.

		GIRL
	It's a relatively straightforward question.

Dade notices her lips, and in his imagination launches
into a flurry of half-second video clips and art bites,
all involving lips and kissing.

		GIRL
	Do you speak English?

		DADE
	Sorry, you wanted...?

		GIRL
	I wanted transfer forms.

He gives them to her.

		GIRL
	Thank you.

She starts leaving. He doesn't.

		GIRL
	Are you coming?

Dade clues in, gets up and follows her. She takes him on
a brief tour.

INT. HIGH SCHOOL CORRIDOR.

		GIRL
	The gym is through there, and the cafeteria is
	through there.

		DADE
	Great. Cool.
		(pause)
	What's your name?

		GIRL
	Kate. Kate Libby.

They arrive at a classroom.

		KATE
	Here's your class.

		DADE
	My... class. You mean I'm not in your class?

		KATE
	No, you're not in my class.

Kate starts away.

		DADE
	Give me time!

A guy in the halls notices Dade.

		GUY
	Hey, you new?

		DADE
	Yeah.

		GUY
	Tell him about the pool, Kate.

		DADE
	Pool?

		KATE
	Yeah, there's an Olympic size swimming pool up
	on the roof. Take the stairs over there.

		DADE
	Yeah! Sure.

Kate starts away again.

		DADE
	Thanks!

EXT. SCHOOL ROOFTOP.

Dade enters, and lets the door slam behind him. Across the
roof, a dozen or so geeky looking kids are looking over
the edge, apparently trying to get someone's attention.
One of them notices Dade.

		GEEK
	Hey! Hold the door!

He's too late. The geeks look pretty angry. There is no pool.

		Dade
		(realizing he's been had)
	No pool.

Dade tries the door but it's locked. He hammers it with
his palm, furious. Above, thunder roars and it begins
raining.

INT. SCHOOL CORRIDOR.

Dade is soaking wet, and trudges among his classmates
leaving a muddy trail. A three-second video clip rolls
through his mind: it is a screaming woman being strangled
in an old movie. He walks past Kate, who giggles.

		KATE
	Oh my God! He found the pool.

INT. SCHOOL COMPUTER LAB.

The kids are all seated at computer workstations. Dade
is hacking, the latino kid who was on the phone to
Venezuela is running a demo involving dirty-dancing
skeletons.

		TEACHER
	I'm Mr. Simpson. And I'm subbing for Ms.
	Bayliss who was arrested at the anti-fur
	rally. I know some of you kids got computers
	at home. But these are school property,
	people, and I don't want to see any gum stuck
	to 'em. Chapter 1. Designing graphical
	interface...

Meanwhile, the latino kid notices that Dade has been
looking up Kate Libby's school records. And hacking
himself into her advanced English class.

EXT. SCHOOL QUAD.

It's after school, kids are heading home, Dade too. The
latino kid notices Dade and catches up with him.

		KID
	So, um, what's your interest in Kate Libby,
	eh? Academic? Purely sexual?

		DADE
	Homicidal?

		KID
	What's up, man? I'm the Phreak!

The name rings no bells with Dade.

		PHREAK
	The Phantom Phreak? The king of Nynex? I
	know you play the game.

Another kid, younger and a little geeky looking, runs up
to Dade and The Phantom Phreak.

		JOEY
	Phreakphreakphreakphreakphreak,
	dudedudedudedudedudedude... I gotta...

		PHREAK
		(slaps Joey)
	Joey, Joey...

		JOEY
	What? whatwhatwhat?

		PHREAK
	One more "dude" out of you and I'm gonna slap
	the shit outa you, okay? Now I'm trying to
	save you from yourself but you gotta stop
	letting your mama dress you, man!
		(To Dade):
	Check it...

Phreak starts to hand Dade a flyer.

		JOEY
		(interrupting)
	I need a handle, man. I don't have an
	identity until I have a handle.

		PHREAK
	You know, you're right about that.
		(to Dade)
	Check it, Friday.

Phreak hands Dade a flyer for Cyberdelia.

		JOEY
	Alright. How about the Master of Disaster,
	huh?

		PHREAK
	You're hopeless, man, utterly hopeless.

Phreak walks away.

		JOEY
	Ultra Laser.
		(desperate)
	Doctor Doom!

EXT. NEW YORK CITY STREET VILLAGE. NIGHT.

Dade rolls in on rollerblades.  Street vendors hawk
computer parts and bootleg software. A bootleg music
vendor catches Dade's attention.

		CEREAL
	Check this out, each and every one of you.
	Compilation tape, of my own making. I call
	this the "Greatest Zooks Album". Featuring
	artists like, well I got some Hendrix on
	there, some Joplin, Mama Cass, Belushi... all
	great artists that asphyxiated on their own
	vomit!

The small crowd around him finally gets the joke.

		CEREAL
	Can't get this in stores, man, I made it!

Dade wheels into Cyberdelia, which just happens to be
equipped with a ramp down to its main floor for the
benefit of skaters. The place pounds with loud, bassy
techno music and coloured light. Video monitors with
psychedelic patterns complete the atmopshere. There is a
video game with a huge screen.  Phreak is at a pay phone.

		OPERATOR
		(on phone)
	Please deposit five dollars for the first
	minute.

Phreak holds a small box up to the receiver, presses a
button, and the box emits a series of tones.

		OPERATOR
	Thank you.

		PHREAK
	Nonono, thank YOU!

Dade checks out the scene. Kate is playing the big video
game. Dade skates up to her. She loses her last man.
She's got the high score, in fact her name dominates the
top-10 list.

		DADE
	That's a nice score for a girl.

		KATE
		(irritated by Dade's presence)
	Think you can do better?

		DADE
	I'll give it a shot.

Kate yields the controls to Dade, who begins playing.
Kate's boyfriend looks on from a mezzanine several feet
above.

		CURTIS
	Is this kid bothering you, Kate?

		DADE
	Sorry, can I get some room here?

		CURTIS
	Yeah.
		(to Kate)
	Why don't you come up here?

Kate obliges and joins Curtis.  Dade continues playing.
He plays brilliantly. The game is a flashy 3-D high-speed
chase game with lots of surprises. Dade loses, but his
high score is about to come up.

		CURTIS
	He's good!

Dade's score comes up. He's in the #1 position. Phreak
is amazed.

		DADE
		(to Kate)
	Well, it looks like I'm on top.

Kate, defeated, leaves. Curtis follows.

		PHREAK
	Congratulations. No one's ever beat her
	before. You just made an enemy for life.
		(to someone else)
	Boy meets world. Let's go?

EXT. OUTSIDE CYBERDELIA. NIGHT.

Kate and Curtis are sucking face, oblivious to the busy
world around them. Dade and Phreak watch, more than a
little disgusted.

		DADE
	Who's that?

		PHREAK
	Curtis.

		DADE
	And what's he do?

		PHREAK
	That's it, you're looking at it, he just looks
	slick all day.

Kate and Curtis start to take off on Curtis' motorcycle.
Kate and Dade make eye contact briefly. The motorcycle
speeds off into the night.

INT. DADE'S ROOM.

The clock says it's 4:16. As the camera pans up to Dade,
it changes to 4:17. Dade is hacking again. It's the
school's administration system. Dade schedules a test of
the school sprinkler system for 9:30am.

INT. HIGH SCHOOL CORRIDIR.

Dade stands alone in the hall, watching the time closely.
Phreak rounds a corner and meets Dade.

		PHREAK
	What's up?

Dade doesn't answer. He watches the time a couple of more
seconds, then opens an umbrella. Immediately the fire
sprinklers turn on. Phreak starts getting drenched. He
realizes what is happening.

		PHREAK
		(amused and highly impressed)
Oh my God. You...

A bell rings and students pour out into the halls by the
hundreds. They're all being showered on. A tall
cheerleader bounces by Phreak, pushing her pom-pom in his
face.

		PHREAK
	Way cool!
		(to Dade)
	You saw that?

Dade nods in the affirmative.

Kate walks up to Dade, also understanding what has
happened.

		KATE
	What the hell is going on?

		DADE
	Pool on the roof must have a leak.

Kate gives Dade a look that could kill and skulks away.

Dade walks away under his umbrella, smug and dry.

		PHREAK
	Man, oh man, this is gonna be good.

INT. HIGH SCHOOL CLASSROOM.

Dade, Kate, and a couple of other students are writing on
the chalkboard. Kate finishes first.

		KATE
	If God gave men brains bigger than dogs',
	they wouldn't hump womens' legs at cocktail
	parties.

The class giggles.

		KATE
	Ruth Libby.

		TEACHER
	I'm not so sure your mother qualifies as a
	significant author of the twentieth century.

		KATE
	Her last book sold two million copies.

		CLASS
		(almost in unison)
	Woooooo!

The teacher reads Dade's quotation.

		TEACHER
	"Angel-headed hipsters burning for the ancient
	heavenly connection to the starry dynamo in
	the machinery of the night."

		DADE
	That's Ginsburg.

		TEACHER
	Nice. Very nice.

		KATE
	He's not in this class.

		DADE
	I said give me time.

		KATE
	He's not enrolled in this class.

		TEACHER
	Well, he's on my list.

Kate leaps across a desk and snatches the list from the
teacher. Dade is on it. She gives Dade another filthy
look, both Dade and the teacher just shrug. The teacher
moves on to Cereal.

		TEACHER
	"Of all the things I've lost, I miss my mind
	the most?"

		CEREAL
	Ozzy Osbourne!

		TEACHER
	You. What is your name?

The teacher grabs the list back from Kate.

		CEREAL
	Uh, Emmanuel Goldstein, sir?

		TEACHER
	You, however, are not on my list.

		CEREAL
		(in mock shock)
	Whoa, this isn't wood shop class?

The class cracks up. Kate and Dade exchange looks as the
teacher escorts Cereal to the door.

INT. DADE'S PLACE.

		MRS. MURPHY
	How was school?

		DADE
		(eating)
	Hmmm.

		MRS. MURPHY
	What did we learn in school today?

		DADE
	Revenge.

		MRS. MURPHY
	Aaaah. Did we meet someone special?

		DADE
	No. No one special.

		MRS. MURPHY
	Okay, I gotta get back to work. I'm gonna be
	home late.  And would you try and please fill
	these out?

She indicates a pile of college applications.

		MRS. MURPHY
	Oh don't worry, it's only the rest of your
	life.

She starts to the door.

		DADE
	Right. Anything else, you want me to mow the
	lawn? Oops, forgot. New York. No grass.

		MRS. MURPHY
	And unpack.

She leaves. Dade looks over the college applications for
a second, and pushes them away. He'd rather not do this
now.

INT. CYBERDELIA.

Dade, Phreak and Joey are sitting at a table. Joey is
giving a dull account of his hacking adventures. Enter
Cereal.

		CEREAL
	FYI, alright man, you can sit at home, and do
	like absolutely nothing and...

Cereal pauses, notices Dade, whom he has never met
formally but seen around, and then continues.

		CEREAL
	...and your name goes through like seventeen
	computers a day. 1984, yeah right man, that's
	a typo. Orwell's here and now, he's living
	large. We have no names, man, no names. We
	are nameless. Can I score a fry? Thanks.

		PHREAK
	Meet Cereal Killer. As in Froot Loops? But
	he does know things.

Dade and Cereal acknowledge each other.

		JOEY
	Anyways, guys, guys, listen, listen to me.
	I'm in this computer right? So I'm looking
	around...

		PHREAK
		(to Cereal)
	D'you bring those Crayola books?

		CEREAL
	Oh yeah, technicolor rainbow.

 Cereal brings a book out of his bag.

		CEREAL
	Green one.

		JOEY
	What is that, what is that? Lemmie see. What
	are these?

		DADE
	International Unix Environments.

Cereal pulls out another book.

		CEREAL
	Luscious orange?

Cereal hands the orange book to Phreak.

		DADE
	Computer security criteria, DOD standards.

Another book comes out.

		DADE
	The Pink Shirt Book, Guide to IBM PCs. So
	called due to the nasty pink shirt the guy
	wears on the cover.

Another one.

		CEREAL
	What's that?

		DADE
	Devil book. The Unix Bible.

Another one.

		CEREAL
	What's that?

		DADE
	Dragon book. Compiler design.

Cereal brings out a large red book.

		CEREAL
	Oh yeah? What's that?

		DADE
	The Red Book. NSA Trusted Networks.
	Otherwise known as the Ugly Red Book that
	won't fit on a shelf.

By now Phreak has made a pile of the books, and the Red
Book looks wholly out of place on the top of the pile.

		JOEY
	Anyway, anyway, guys guys guys, come on. I'm
	in this computer, right. So I'm looking
	around, looking around, you know, throwing
	commands at it, I don't know where it is or
	what it does or anything. It's like, it's
	like choice, it's just beautiful, okay. Like
	four hours I'm just messing around in there.
	Finally I figure out, that it's a bank.
	Right, okay wait, okay, so it's a bank. So, this
	morning, I look in the paper, some cash
	machine in like Bumsville Idaho, spits out
	seven hundred dollars into the middle of the
	street.

		CEREAL
	That's kinda cool.

		JOEY
	That was me. That was me. I did that.

		DADE
	You did this from your house.

Joey takes a drag from his cigarette and just nods, with a
big grin on his face.

		PHREAK
	What are you, stoned or stupid? You don't
	hack a bank across state lines from your
	house, you'll get nailed by the FBI. Where
	are your brains, in your ass? Don't you know
	anything?

		CEREAL
	Stupid, man. It's universally stupid.

		JOEY
	You guys always think I should know
	everything, and you never tell me anything.
	Am I right?

		PHREAK
	Alright, what are the three most commonly used
	passwords?

		JOEY
	Love, secret, and uh, sex.  But not in that
	order, necessarily, right?

		CEREAL
	Yeah but don't forget God. System operators
	love to use God. It's that whole male ego
	thing.

		PHREAK
	Look, you wanna be elite? You gotta do a
	righteous hack. None of this accidental shit.

		CEREAL
	Oh yeah, you want a seriously righteous hack,
	you score one of those Gibsons man. You know,
	supercomputers they use to like, do physics,
	and look for oil and stuff?

		PHREAK
	Ain't no way, man, security's too tight. The
	big iron?

		DADE
	Maybe. But, if I were gonna hack some heavy
	metal, I'd, uh, work my way back through some
	low security, and try the back door.

		CEREAL
	Yeah but oh man,
		(starts rubbing one of his
		own nipples in mock sexual
		excitement)
	wouldn't you just love to get one of those
	Gibsons, baby? Ooooh!

		PHREAK
	Yo, who ate all of my fries?

Cereal pauses a second.

		CEREAL
		(pretending to be enraged)
	Joey?!

		JOEY
	What, no, nonononono, I didn't touch your
	fries. I did not touch your fries.

		PHREAK
	Cereal, man, you owe me a pack.

		CEREAL
	It was him, man!

		PHREAK
	You're psyched. You need to lay off of that
	shit.

		CEREAL
		(to Joey)
	I'm gonna hit you!

INT. JOEY'S ROOM. NIGHT.

Joey is hacking. A Gibson. He gets in. Using GOD as a
password. Nice graphics represent the machine's vast
systems.

		JOEY
	YES! Home run, home run. You and me Lucy.
	We're gonna show em baby.

INT. COMPUTER ROOM, ELLINGSON MINERAL.

A system operator at Ellingson Mineral Corporation, a
large oil company, notices the intrusion. He gets on the
phone.

INT. PLAGUE'S LOFT.

The place is a mess, typical of the hacker bachelor pad.
Empty chinese food boxes and Jolt Cola cans litter the
place.

Plague's phone is ringing, waking him.

		HAL
		(on phone)
	Mr. Belford?

		PLAGUE
		(sleepily)
	My name is the Plague.

		HAL
	Uh, Mr. The Plague, uh, something weird's
	happening on the net.

		PLAGUE
	As in what, you hapless techno-weenie?

		HAL
	Uh, the accounting subdirectory in the Gibson
	is working really hard. We got one person
	online, the workload is enough for like ten
	users. I think we've got a hacker.

INT. JOEY'S ROOM.

		JOEY
	Okay, okay, we need proof that we were here.
	Right, uh...

Joey starts looking for something to download as proof he
was there.

		JOEY
	Yeah, Garbage, okay, give me Garbage.

He selects a Garbage file and starts the download. His
screen becomes a psychedelic mind trip.

INT. COMPUTER ROOM, ELLINGSON MINERAL.

The Plague glides in on a skateboard. Short and thin,
bearded, about 35 but still trying to be a teenage
anarchist, yet not consciously realizing he sold out that
ideal years ago.

		PLAGUE
	Never fear. I is here.

		HAL
	I've narrowed the activity to terminal 23.

		PLAGUE
	Let's echo 23, see what's up.

The huge monitor lights up with the display of the
Gibson's resources. Hal and the Plague watch. Plague
starts "surfing" around.

		PLAGUE
	"God" wouldn't be up this late.

He sees what Joey is downloading. A file called
"Garbage".

		PLAGUE
	Shit! Get me the switching control center.

He puts on a telephone headset. Hal dials for him.

		PLAGUE
		(into the headset)
	I need to trace a call that's in progress.

INT. JOEY'S ROOM.

Joey is sneaking a cigarette while his computer downloads.
There is a knock at the door. It's his mother.

		JOEY
		(whispering)
	Shit!
		(loudly, panicked)
	Uh yeah... hold on, mom. Hold on one second.

He puts out the cigarette and sprays the room with air
freshener.

		JOEY'S MOM
	I mean it! Open the door, Joseph.

		JOEY
	Yeah, uh, yeah, okay.

He unlocks the door. Joey's mom bursts in. He's still
clambering into bed.

		JOEY
	There you go.

		JOEY'S MOM
	Bed. Sleep. Now!

She turns off the computer. It wasn't finished
downloading.

		JOEY'S MOM
	Sweet dreams, Joey.

INT. COMPUTER ROOM, ELLINGSON MINERAL.

		HAL
	He's gone!

		PLAGUE
	Did you get a trace?

		OPERATOR
		(on phone)
	Yeah, we got him.

		PLAGUE
		(smiling)
	Good.

INT. JOEY'S ROOM. DARK.

Joey takes a disk out of his computer and stashes it in an
air vent in the cieling.

INT. TENEMENT HALLWAY.

Phreak, Dade and Cereal are rollerblading through the
halls of an apartment building that is filled with
graffiti. It appears that most of the spray-bomb art was
created by the residents.

		CEREAL
	Nice place, huh.

Cereal knocks on a door spray-painted "Hackstock"

		DADE
	You heard of a hacker called Acid Burn? You
	know who he is?

		PHREAK
		(surprised)
	No, don't know who he is.
		(to Cereal)
	Do you?

Cereal shrugs.

A hooded black man in his early twenties answers the door.

		PHREAK
	Nikon! Lord Nikon this is...

Phreak motions to Dade.

		DADE
		(finishing)
	Crash Override.

		NIKON
	Never heard of you. Done anything?

		DADE
	No.

Nikon slams the door.

		PHREAK
	Come on!

Phreak knocks the door again. Nikon opens again.

		NIKON
	What, your mom buy you a 'Puter for Christmas?
		(to Phreak)
	Does he know anything?

		PHREAK
	Sure man, he's elite.

		NIKON
		(pausing, checking Dade out)
	Come in.

		CEREAL
	Uh... Nikon, can I... can I crash at your
	place tonight?

		NIKON
		(removing his hood)
	Again?
		(pauses, then grins broadly)
	Yeah sure.

Nikon and Cereal do a fake Kung-fu move together.

		BOTH
	Ooka-pow!

INT. NIKON'S PLACE.

Later, the four are watching TV. On TV is a secret
service agent giving a news interview.

		GILL
		(on TV)
	Hackers penetrate and ravage delicate public
	and privately owned computer systems,
	infecting them with viruses, and stealing
	materials for their own ends. These people,
	they are terrorists.

		CEREAL
	Agent Richard Gill, You're hacker enemy number
	one, man. You're a boner!

		NIKON
	Yo, showtime, showtime!

		DADE
	What's going on?

		ALL BUT DADE
		(in unison)
	4...3...2...1...

Cheesy music plays. Razor and Blade, androgynous asian
brothers, have a community access TV show. "Wayne's World"
in eye liner.

		RAZOR
	Welcome to our show!

		BLADE
	Hack the Planet!

		ALL BUT DADE
	Hack the Planet!

		RAZOR
	For those late night hacks...

		BLADE
	Jolt Cola! The soft drink of the elite
	hacker.

		DADE
	Who are these guys?

		NIKON
	That's Razor and Blade.

		DADE
	Razor and Blade.

Now Razor and Blade have a disconnected payphone in their
studio.

		RAZOR
	That's right, this IS a payphone.

		RAZOR AND BLADE
		(in unison)
	Don't ask.

		BLADE
	As you can see, this is just a simple
	microcassette recorder. (shows the
	microcassette recorder)  Hook it up to the
	phone and drop in five bucks in quarters.

		RAZOR
	Record the tones that the coins make. And
	hang up and get your money back!

		BLADE
	And never again have to pay for a service that
	would be dirt cheap...

		RAZOR
	...IF it weren't run by a bunch of
	profiteering gluttons!

		BLADE
	Remember, hacking is more than just a crime.
	It's a survival trait!

INT. JOEY'S PLACE.

Joey is taking a shower, wearing walkman headphones,
singing along with the music. Joey finishes, turns off
the shower, still singing. He draws open the shower
curtain to find two secret service agents with shotguns
pointed at him.

		SS AGENT
	FREEZE!

		JOEY
	What? What? What did I do? What?

The agents drag Joey, still naked and wet, out of the
shower and into the living room. His mother is
hysterical..

		JOEY'S MOM
	Joey!

		AGENT
	Get in there! Sit down!

		ANOTHER AGENT
	Stay down there. Don't move.

Joey is pushed into a sofa. He sees his computer, "Lucy",
being carried away.

		JOEY
	Lucy!

Joey dives onto the agent carrying Lucy away, losing his
towel.  His mother, seeing his exposed buttocks, is
shocked.

		JOEY'S MOM
	JOEY!!!

EXT. OUTSIDE JOEY'S PLACE.

A police-type vehicle pulls up. It's Agent Richard Gill
of the Secret Service.  He stops a young agent for an
update.

		GILL
	How's it going, Ray?

		AGENT RAY
	It looks good, sir. We've got an uncorrupted
	hard drive.

		GILL
	In English, please. I didn't spend ten years
	protecting the president so I could finish my
	career feeling like an idiot.

		AGENT RAY
	I'm sorry, sir. We caught him by surprise, so
	we don't think he had time to erase his
	computer files.

		GILL
	Good. Good man. Alright, let's finish up
	here, and take him in for interrogation.

		AGENT RAY
	Alright sir.

They split up.  A reporter and her sound man run up to
Gill.

		REPORTER
	Agent Gill, can you spare a moment of your
	time?

		GILL
	Why of course, Jennifer.

While Jennifer conducts the interview, agents lead Joey
into an unmarked car. His mother is behind him, still
hysterical.

		JOEY'S MOM
	Joey!

		JOEY
	Mom...

		JENNIFER
	Just how dangerous are hackers?

		GILL
	Well, hackers penetrate and ravage delicate
	public and privately owned computer systems,
	infecting them with viruses...

		JOEY'S MOM
	Joey!

		GILL
	...and stealing sensitive materials for their
	own ends. These people, they're terrorists...

		JOEY'S MOM
	Joey!

INT. ELLINGSON MINERAL CORPORATION.

A tall, impressive building. A cavernous atrium filled
with busy people.

INT. ELLINGSON BOARDROOM.

A handsome looking woman in her late thirties walks in.

		MARGO
	Good morning, Gentlemen. Please be seated. I
	see we're still dressing in the dark, Eugene.

		PLAGUE
		(to Margo)
	Once again, don't call me Eugene.
		(to the board)
	A recent unknown intruder penetrated, using a
	superuser acount, giving him access to our
	whole system.

		MARGO
	Precisely what you're paid to prevent.

		PLAGUE
	Someone didn't bother reading my carefully
	prepared memo on commonly used passwords.
	Now, as I so meticulously pointed out, the for
	most used passwords are love,
		(gesturing lewdly)
	sex, secret and...
		(eyeing Margo)
	...God. So would your holiness care to change
	her password?

Margo just blinks prettily.

		PLAGUE
	A hacker planted the virus.

		MARGO
	Virus?

		PLAGUE
	Yesterday, the ballast program for a
	supertanker training model mistakenly thought
	the vessel was empty, and flooded its tanks.

		MARGO
	Excuse me?

		PLAGUE
		(as if to a child)
	The little boat flipped over. A virus planted
	in the Gibson computer system claimed
	responsibility.

		MARGO
	What, it left a note?

Plague hits a button on a remote control, and the virus -
a long haired male model - appears on a large screen, in
psychedelic colors. The virus speaks in a hammy Italian
accent.

		VIRUS
	Unless five million dollars are transferred to
	the following numbered account in seven days,
	I will capsize five tankers in the Ellingson
	fleet.

		BOARD MEMBER
	Is that...

		PLAGUE
		(interrupting)
	That is the virus. Leonardo da Vinci. The
	problem is we have twenty six ships at sea and
	we don't know which ones are infected.

		DUKE ELLINGSON
	Well then, put the ships' ballasts under
	manual control.

		PLAGUE
	There's no such thing anymore, Duke. These
	ships are totally computerized. They rely on
	satellite navigation, which links them to our
	network, and the virus, wherever they are in
	the world.

		MARGO
	So what are we supposed to do?

		PLAGUE
	Well luckily, you have a gifted and talented
	security officer. I traced the hacker's call.
	The secret service picked him up this morning.
	I'll just search his files for the original
	virus code, and then I can eliminate it.

INT. ELLINGSON MINERAL ATRIUM.

Plague, Margo and two suits from the boardroom are riding
down an escalator.

		SUIT #1
	Now look, now we expect you to get onto this
	right away, yeah?

		PLAGUE
	Yeah!

		SUIT #1
	Well, how soon?

		PLAGUE
	Well, we're working on it as fast as we can.
	This is a very common occurrence in
	corporations as large as ours. You have
	nothing to worry about.

		SUIT #2
	Yeah, right.

		SUIT #1
	Now, you're sure about that, Mr. The Plague?

		PLAGUE
	Yeah, the Secret Service is helping us out 100
	percent. Okay?

		SUIT #2
	Yeah.

		SUIT #1
	Okay.

		PLAGUE
	We'll be in touch. Talk to you later.

The suits get off the escalator, Plague and Margo take the
next one down.

		MARGO
	What the hell was that all about?

		PLAGUE
	I had to move fast. The hacker copied my
	garbage file.

		MARGO
	What?

		PLAGUE
	I created Mister da Vinci so we could call in
	the Secret Service. So they'd arrest the
	hacker, sieze his equipment, things that we
	can't do on our own.

		MARGO
	I don't want to go to jail for this.

		PLAGUE
	Relax. Think about the 25 million dollars.

		MARGO
	But you've created a virus that's going to
	cause a worldwide ecological disaster, just to
	arrest some hacker kid?

		PLAGUE
	Basically, uhmm, yeah. Mmm hmmm.

		MARGO
	Jesus. You know, you're sick, Eugene. You...

		PLAGUE
	Sh, sh sh sh sh.

Plague stops a passing secretary and snatches a piece of
paper from her hand.

		PLAGUE
	I'll take care of this.

		SECRETARY
	Alright, sir.

		PLAGUE
	I can cancel it any time. I don't need any
	program code. But it's the perfect cover, to
	confiscate the disc and find out how much of
	that garbage file has been copied.

		MARGO
	Get it!
		(walking away)
	Why did I ever trust you?
		(going back up the escalator)
	Get the file. Otherwise you'll lose all your
	toys.

INT. SECRET SERVICE INTERROGATION ROOM.

Joey is distraught over the dismantling of Lucy. Agent
Ray examines the Mac's innards.

		GILL
	Did you find the program for the virus on any
	of the discs we confiscated?

		PLAGUE
	No. He's either very smart or very stupid.

		GILL
	Then he stashed it somewhere, or he has an
	accomplice. We'll release him until his
	indictment, keep tight surveillance, and see
	if he leads us to your disc.

EXT. OUTSIDE JOEY'S PLACE.

Joey's apartment building is an L-shaped skyscraper about
30 storeys high, unimpressive by New York City standards.
Two Secret Service agents are staking Joey out in a car
outside.

		SECRET SERVICE AGENT BOB
	Unit 3 outside suspect Joey Pardella's
	apartment. Nothing to report. Suspect still
	grounded... by his mother.

His radio crackles.

		AGENT BOB
	Listen to this bullshit.
		(he reads)
	"This is our world now. The world of the
	electron and the switch, the beauty of the
	baud. We exist without nationality, skin
	color, or religious bias. You wage wars,
	murder, cheat, lie to us and try to make us
	believe it's for our own good, yet we're the
	criminals. Yes, I am a criminal. My crime is
	that of curiosity. I am a hacker and this is
	my manifesto." Huh, right, manifesto? "You
	may stop me, but you can't stop us all."

		AGENT RAY
	Now that's cool.

		AGENT BOB
	Cool?

		AGENT RAY
	Yeah, cool.

		AGENT BOB
	You think it's cool?

		AGENT RAY
		(not caring for where Bob is going
		with this)
	It's cool!

		AGENT BOB
	It's not cool. It's commie bullshit!

INT. HIGH SCHOOL BOYS' ROOM.

Dade, Cereal and Phreak check their faces. Cereal brushes
his teeth.

		CEREAL
		(to Phreak)
	So what do you think, can I crash at your
	place tonight?

		DADE
	What is it with this guy?

		PHREAK
	His parents missed Woodstock and he's been
	making up for it since. Hey, you hear about
	Joey's bust?

		CEREAL
	Yeah. Probably had something to do with that
	bank in Idaho.

		PHREAK
	Do you think he could hack a Gibson?

		DADE
	Did you talk to him?

		PHREAK
	Nope. His mom said he's grounded for his next
	three lifetimes.
		(imitating her)
	He isn't to consort with his computer friends.
		(himself again)
	The secret service is really out to get him.
		(changes the subject)
	Hey there's a big party tonight, you wanna go?

Dade shakes his head.

		PHREAK
	It's at Kate's...

Dade just smiles.

		PHREAK
	 Thought so!

Cereal and Phreak leave, Cereal dancing.

INT. PLAGUE'S OFFICE.

Plague is wearing a VR helmet and gloves, playing some
sort of action game. He is unaware that Gill has just
entered the room.

		GILL
	What the hell are you doing? Plague!

He thumps the VR pedestal.

		GILL
	PLAGUE!

Plague finally notices, and takes off the helmet.

		PLAGUE
	Gill.

		GILL
	I think we've got something.

Gill hands Plague a folder. It has the logo of Stanton High.

		PLAGUE
	Uuugh, hard copy.

Plague looks it over and recognizes a name.

		PLAGUE
	Dade Murphy.

INT. DADE'S PLACE.

It's after school. Dade's just unlocking the front door,
only to find a Secret Service agent behind it.  And one
behind him in the hallway. Both point pistols at him.

		AGENT RAY
	Secret Service!

		AGENT BOB
	Don't move!

They slam Dade against a wall and start frisking him.

		DADE
	Christ! What is the...

		AGENT BOB
	Shut up!

		DADE
	What are you doing, man? Get off me!

They lead him into his room and throw him down on the bed.
Plague is there.

		AGENT BOB
Just sit in the bed and keep your hands where we can see
them.

		PLAGUE
	The year was 1988.  And this nasty virus
	crashed fifteen hundred systems in one day.

Dade has a flashback.

		DADE
	Fifteen hundred and seven.

		AGENT RAY
		(astounded)
	Wow, huh!

		GILL
	It got you seven years probation. No
	computer, couldn't even use a touch tone
	phone.

		PLAGUE
	Must have been hell, huh? Zero Cool?
		(getting to the point)
	A virus has been planted in the Ellingson
	Mineral computer system. You were our prime
	suspect, till we trashed your stuff and found
	no trace of it.

		GILL
	However, we have come to believe that one Joey
	Pardella is involved in this Ellingson virus.
	He or perhaps his accomplice has a disk that
	Mr. Belford needs to disable that virus. We
	want you to help us find it.

		PLAGUE
	Gill.

The three secret service agents leave Plague and Dade
alone.  Plague shuts the door behind them.

		PLAGUE
		(of Gill)
	Loser.
		(continues)
	I can't believe you were only eleven when you
	wrote this. It's quite an impressive virus.
	Dade, I know how you might feel about narking
	on your friends, but, we're hackers. For us,
	there's no such thing as family and friends.
	We're each our own country, with temporary
	allies and enemies. I'd like to make a treaty
	with you.

		DADE
	I'm sorry. Who are you?

		PLAGUE
	I'm the one who understands you. Now, can we
	be allies?

		DADE
	Nah. I don't play well with others.

Plague is holding Dade's baseball bat. He shrugs, turns
around, and smashes Dade's stereo to smithereens.

		DADE
	Shit! Come on!

		PLAGUE
	Watch which friends you do play with. A
	record like yours could land you in jail, get
	you kicked out of school, no colleges would
	take you. No future. Exiled from everyone and
	everything you love.

Plague replaces the baseball bat.

		PLAGUE
	I'll be in touch.

Plague leaves.

		PLAGUE
		(to agents)
	I'm fine.
		(to Dade)
	Oh, and Dade, try to stay out of trouble, okay?

		DADE
	Blow me.

		PLAGUE
		(smiles)
	Thank you!

INT. DADE'S ROOM. LATER.

Dade is lying in bed. A door opens. It's Kate. She opens
her motorcycle jacket, revealing her bare breasts. Dade
starts to get up, she pushes him back own on the bed and
starts kissing him passionately. He responds in kind.
Then, Gill, Agent Ray and Agent Bob burst into the room,
handcuff him, break the two up and haul them away as
Plague looks on smugly.

Then Dade wakes up in a sweat.  It was only a dream. He
regains his composure.  The sound of New York City at
night surrounds him. He goes back to sleep.

INT. KATE'S PLACE.

The party. A large, well-furnished apartment in an
elegant old skyscraper in the fashionable part of town.
Teenagers dance and writhe to loud, bassy music. Dade and
Phreak arrive.

		PHREAK
	Her mom makes big bucks writing self-help
	books for women. Stuff like "Women Who Love
	Men Who Are Emotional Amoebae"

Phreak shows Dade the book.

		DADE
	That explains a lot.

Kate, the lovely and gracious hostess, mingles and greets
her many guests, not noticing Dade or Phreak. Cereal
offers Dade a drink from a plastic bottle. Dade, not
knowing what he's in for, drinks. Nikon is the Deejay.

		PHREAK
		(loudly)
	Yo, what's up Nikon!

		NIKON
	Yo Phreak! Dade, man, you made it.
		(to Cereal)
	Houston, we have liftoff, 3 o'clock,
	check it... don't look right away, what's
	wrong with you! Look at her man...

Nikon and Cereal are checking out a truly fine babe.

		NIKON
		(concentrating)
	Look out, man. Lisa Blair, 26 East 7th St.,
	apartment 16, 555-4817, BOOM!

		DADE
	How did you know that?

		NIKON
	I got photographic memory.
		(Smiling)
	It's a curse!
		(Into the crowd)
	Lisa!

		LISA
	Hey, how do you know my name?

Cereal and Phreak move through the crowd. Cereal notices
something.

		CEREAL
	Oooo, look at that pooper man. Spandex, it's
	a privilege, not a right!

INT. MEETING HALL.

A 12-step recovery group. Addicts, including Joey
Pardella, sit in a semi-circle.

		VICKIE
	Hi, my name is Vickie, and I'm an addict.

		HANK
	Hi, my name is Hank, and uh, I'm an addict.

		JOEY
		(smoking)
	Uh, my name's Joey but, uh, I'm not an addict.

Joey takes a drag. The group reacts indignantly.

		JOEY
	Nono, really, really, listen, listen to this.
	I got in trouble with my computer, right,
	okay, and my lawyer told the judge that I'm an
	addict, but I'm not addicted to my computer!
	No really, really,

Joey takes another drag.

		JOEY
	I'm not an addict. I'm not, I'm not.

Joey downs his coffee.

		JOEY
	Can I get some more coffee?

INT. KATE'S BEDROOM.

Phreak is checking out Kate's computer.

		PHREAK
	Yo. Check this out guys, this is insanely
	great, it's got a 28.8 BPS modem!

		DADE
	Yeah? Display?

		CEREAL
	Active matrix, man. A million psychedelic
	colors. Man, baby, sweet, ooo!

		NIKON
	I want it.

		PHREAK
	I want it to have my children!

		CEREAL
	Yeah, I bet it looks crispy in the dark.

		PHREAK
	Yo, hit the lights.

	Dade hits the lights. The four ooo and ahh at
	its graphics. Kate and Curtis walk into the
	room and hit the bed, unaware of the hackers
	in the corner by her laptop.

		DADE
		(whispering)
	Shit!

		CEREAL
	Shh!

		DADE
	Was that her top?

		PHREAK
	One-handed!

		CEREAL
	Difficulty rating?

		NIKON
	Seven. Wow! Burn's wetware matches her
	software!

		DADE
		(loudly)
	Burn!

Their cover is blown.

		NIKON
	What the f...

Cereal hides under the desk.

		KATE
	Hey! What are you guys doing in here?

		PHREAK
	I'm sorry, we're sorry, just checking out your
	fly laptop!

		NIKON
	Yeah, it's hyped, you know... you're in the
	butter zone now, baby.

		PHREAK
		(smiling)
	Uh-huh!

		KATE
		(her tone changing)
	Yeah, it is...
		(she comes over to it)
	I wanna triple the RAM...

		CURTIS
	Oooh, Leopard Boy... AND the Decepticons. Uh,
	Kate, Kate, you're not going into that
	computer shit now, right?

Kate barely acknowledges him.

		CURTIS
		(cynically)
	Humm, yeah.

Curtis leaves.

		CEREAL
		(mockingly)
	Right.

		DADE
	The sensitive type.

Kate finally notices that Dade, whom she didn't invite, is at her
party and in her bedroom.

		KATE
	What is he doing in here?

		PHREAK
	Relax, Burn, he's my guest.

		DADE
	Burn. You're Acid Burn. You booted me out of
	OTV!

		KATE
	What?

		DADE
	I'm Crash Override.

		KATE
	You're the moron that's been invading my turf?

		CEREAL
	Whoa, whowhowhowhoa.
		(motioning to Dade)
	Crash...
		(motioning to Kate)
	and Burn!

Cereal breaks into hysterics.

INT. PLAGUE'S LOFT.

Plague is hacking.

		MARGO
	Murphy kid turn you down?

		PLAGUE
		(in a hammy southern accent)
	I disguised myself as an Alabama State Trooper
	and penetrated the FBI NCIC.

		MARGO
	Pervert! What are you talking about?

She turns her back to him. He does up the zipper on her
dress. Their relationship becomes apparent.

		PLAGUE
	The FBI computer holds files on twenty million
	Americans.  I just hacked into it.

		MARGO
	Congratulations.

		PLAGUE
	From here I got access to every piece of data
	ever stored on Dade Murphy's parents. His
	parents separated five years ago, reconciled
	two years later, filed for divorce last year,
	custody battle, boy chose to go with his
	mother. Hmm.

		MARGO
	So?

		PLAGUE
	So, we get the mother, we get the boy.

INT. KATE'S ROOM.

Kate's room is empty, and Dade can't resist going back in
to play with her laptop, which far outclasses his own,
some more. On the balcony, Kate notices and comes back
in.

		KATE
	What the hell are you doing?

		DADE
	It's cool, I'm just looking.

		KATE
	It's too much machine for you.

		DADE
	Yeah?

Dade starts working furiously on it.

		KATE
	I hope you don't screw like you type.

Dade slows to a two-finger keypoke, not missing a beat.

		DADE
	It has a killer refresh rate.

		KATE
	P6 chip. Triple the speed of the Pentium.

		DADE
	Yeah. It's not just the chip, it has a PCI
	bus. But you knew that.

		KATE
	Indeed. RISC architecture is gonna change
	everything.

		DADE
	Yeah. RISC is good.

They uncomfortably exchange glances.

		DADE
	You sure this sweet machine's not going to
	waste?

		KATE
	Crash Override. What was it. "Mess with the
	Best, Die Like the Rest?"

		DADE
	Yeah.

		KATE
	Are you challenging me?

		DADE
	Name your stakes.

		KATE
	If I win, you become my slave.

		DADE
		(intrigued)
	Your slave?

		KATE
		(realizing his mind is in the
		gutter)
	You wish. You'll do shit work, scan, crack
	copyrights, whatever I want.

		DADE
	And if I win?

		KATE
		(giggles)
	Make it my first born.

		DADE
	Make it our first date.

		KATE
	You're not gonna win.

		DADE
	And you have to smile.

		KATE
	I don't do dates. But I don't lose either, so
	you're on.

MONTAGE: Scenes of Dade and Kate preparing for the challenge.

		PHREAK
		(voice over)
	So here's the deal. The chosen contest: To
	hassle Secret Service Agent Richard Gill, and
	get one back for Joey.

Dade spray paints camouflage onto his keyboard.

		NIKON
	Our decisions are final, by a vote of 2 to 1.
	No appeals.

Kate rifles through her address book.

		CEREAL
	The duel will last until we declare a winner.

Dade plays quick-draw with disks.

		PHREAK
	Use only the dialups, access codes and
	passwords in your collection. Can't ask for
	any help from us.

Dade, having mastered the quick-disk-draw in the mirror,
looks satisfied.

		DADE
		(into mirror)
	Talking to me?

All five are together at the beginning of the challenge.

		PHREAK
	Any questions?

		KATE
	Yeah. Whose gonna notify his next of kin?

Dade and Kate shake hands and the challenge begins.

EXT. NEW YORK CITY PUBLIC PHONE.

At a public phone, Kate hacks into Concourse Bank, looks
up Richard Gill, and has his credit card maxed out.
"Destroy Card" is the final instruction. The other
hackers look on.

INT. RESTAURANT.

A waiter runs a credit card through a validation machine,
sees the message and returns to the patron's table. It is
Richard Gill. Right there, the waiter chops the
MasterCard in two with a pair of scissors, to Gill's
horror.

EXT. NEW YORK CITY PUBLIC PHONE.

Dade hacks into an electronic personal ads system and
changes an ad.

		KATE
	Alright, he's in the personal ads.
		(reading Dade's ad)
	"Disappointed white male, crossdresser, looking
	for discreet friend to bring dreams to
	reality. Leather, lace, and water sports.
	Transvestites welcome."

INT. GILL'S OFFICE.

At his office, Gill is on the speaker phone with someone
responding to the ad.

		GILL
	I... I... I know where you can stick it... I
	know where you can stick it...

Gill punches a button on the phone, another caller comes
on.

		CALLER
	...wanna lick your earlobes... I wanna lick
	your lips... I wanna lick your toes... I
	wanna lick your ankles...

		GILL
	Awww, yeah, you wanna lick something? Lick this.

Gill punches another button, another caller comes on.

		CALLER
	That's why they call me Stallion...

		GILL
	Aw, that's disgusting!

Gill punches another button.

		CALLER
	My heart is steaming for you...

Gill punches another button. He is becoming quite flustered.

		CALLER
	...spank you with my...

		GILL
	Aww, Spank your ass...

He punches another button.

Another caller comes on, and Gill hangs up the phone,
disgusted, offended, and distraught. The Plague is there,
witnessing the whole thing.

		PLAGUE
	Animal!

EXT. EMPIRE STATE BULDING OBSERVATION DECK.

It's Kate's turn. Kate is hacking into the Department of
Motor Vehicles. She adds 113 traffic violations and DUI
offender status to Gill's record.

EXT. NEW YORK CITY, BUSY STREET.

Gill is being arrested quite forcefully by a NYC police
grunt.  He is thrown onto the hood of his car and
handcuffed.

		GILL
	 Hey! Hey, ow! Do you know who I am? Do you
	 know who I am?

EXT. CHINATOWN, PUBLIC PHONE.

Dade's turn. He hacks into the Secret Service's personnel
file, and changes Gill's status to "Deceased."

INT. GILL'S OFFICE.

		EMPLOYEE
		(on phone)
	This is accounting, sir. You enquired about
	an employee of ours, an Agent Richard Gill?

		GILL
	Yes.

		EMPLOYEE
	Our records indicate he's deceased.

		GILL
	I'm what?

INT. CYBERDELIA.

The five are playing pool.

		DADE
	Dead.

		PHREAK
	Dead?

		DADE
	Yeah. Like Rigor Mortis, Habeas Corpus.

		NIKON
	Very impressive.

		CEREAL
	Super hero like even.

		KATE
	Yeah, whatever. What's the score?

Phreak clicks the pool scoreboard so it says 60 - 60.

		PHREAK
	Tie.

The other four protest.

		PHREAK
	Due to Mr. Gill's untimely demise and
	everything, I guess you two will have to
	improvise the next round.

		DADE
	Right. If I win, you wear a dress on our
	date.

		KATE
	And if I win, so do you.

Dade thinks about it a second.

		DADE
	Deal.

Kate gives Dade a look that says "I'm going to hold you to
that."

INT. KATE'S BED. NIGHT.

A shapely figure wearing a red leather legless suit with a
zipper that goes all the way around the crotch. Hands
caress the sultry figure as the camera pans up. The body
belongs to Dade Murphy.

Kate wakes up gasping.  It was only a dream. She pants
and regains her breath. Then she smiles. She enjoyed
that dream.

		KATE
	Oooohhhh...

INT. HIGH SCHOOL HALLWAY.

	Kate, at her locker, stops Dade.

		KATE
	Dade. I didn't know your size, so I guessed.

She opens her locker to reveal a red leather bustier and
bikini bottom.

		KATE
	You are man enough to stick with the deal,
	aren't you?

Dade walks off.

INT. DADE'S PLACE.

Dade signs an electronic pad for a package from UPS. He
takes the package.

		DADE
	Thanks.

He closes the door and opens the package. It is a laptop
computer, clear plastic shell, full colour screen. Very
high-end, perhaps the equal to Kate's machine. He turns
it on. The Plague's face, distorted, appears. It speaks.

		PLAGUE
	You wanted to know who I am, Zero Cool? Well
	let me explain the New World Order.
	Governments and corporations need people like
	you and me. We are samurai. The keyboard
	cowboys. And all those other people out there
	who have no idea what's going on are the
	cattle. Mooo! I need your help, you need my
	help. Let me help you earn your spurs. Ahh,
	think about it. Enjoy the laptop, "Cool"!
	Tell me where the disk is.

Plague's face vanishes.

INT. JOEY'S ROOM.

Joey lies on his bed with a comic book, looking
despondent. His mother enters.

		JOEY'S MOM
	You look pitiful. Okay, okay, you're not
	grounded anymore.

She kisses his forehead and leaves. He springs back to
life, gets up and gets the disc from where he stashed it
in the air vent.

EXT. PARK.

Joey is nervously waiting on a park bench. Phreak arrives.
Agents Ray and Bob still have Joey staked out.

		PHREAK
	Yo, what's up?

		JOEY
	Dude dude dude, I gotta talk to you a minute,
	listen listen listen. I copied a garbage file
	from...

		PHREAK
	Big deal. A garbage file's got shit in it,
	Joey, come on.

		JOEY
	Nono, it's like hot or something. I don't know.

		PHREAK
	Joey, a garbage file holds miscellaneous data.
	Junk. Bits of stuff that's been erased, man.

		JOEY
	I copied it from Ellingson, okay? They're
	asking me about it, alright? Will you take a
	look for me?

Joey hands Phreak the disc. Agent Bob is taking pictures,
and Phreak notices.

		PHREAK
	Oh shit, Joey, you've got a tail.

Joey sees, and runs for it.

		JOEY
	Shit!

The agents split up, one runs after Joey, the other after
Phreak.

INT. HIGH SCHOOL BOYS' ROOM.

Phreak has lost his tail. He puts Joey's disc behind a
condom machine in the boys' room at school, and sticks it
there with gum.

INT. PHREAK'S ROOM.

Phreak frantically destroys all records of his hacking
career. He knows he's about to be busted.

DREAM SEQUENCE.

The Secret Service is about to burst in on Phreak. He
still hasn't destroyed any records, and starts manically
going through everything. Gill is on his laptop screen.

		GILL
	I'm watching you...

INT. PHREAK'S ROOM. MORNING.

A knock on the door. Phreak awakes. It's his mother.

		PHREAK'S MOM
	Ramon? Wake up. Ramon! Wake up! Vamano.
	Time for school, come on.

The secret service bursts in through the window just as
Phreak's mom opens the blind. She screams, Phreak leaps
to his feet.

		AGENT
	Secret Service, don't move!

		PHREAK
	Deja vu!

		AGENT BOB
	Ray Sanchez, you are under arrest, under the
	Computer Fraud and Abuse Act of 1986.

Phreak's mom becomes very angry and starts slapping
Phreak, cursing in Spanish.

		PHREAK
	What are you waiting for, arrest me already!

INT. POLICE STATION LOCKUP.

The undersized Phreak is just a morsel to the hardened
thugs behind these bars and they taunt him viciously as he
is led to his one phone call.

		COP
	You get one call. Uno. Understand?

The cop locks the dial on the phone.

Phreak waits for the cop to leave, and hangs up. He
starts rapidly pushing the hangup hook, and he hears a
ringing tone.

		OPERATOR
	Hello, operator services.

		PHREAK
	Hello, operator? I'm having trouble dialing a
	number.

		OPERATOR
	What number please?

		PHREAK
	555-4202.

		OPERATOR
	Just one moment.

		PHREAK
	Thank you.

Kate answers.

		KATE
	Hello?

		PHREAK
	Hey, it's me.

		KATE
	Phreak?

		PHREAK
	I'm freaking! Joey wasn't making it up! He
	really hacked into Ellingson! He gave me the
	disc with a file he copied and now I'm in
	jail! They're charging me with some serious
	shit! And there's stuff I didn't even do,
	like inserting some virus called Da Vinci, and
	they keep asking about you guys.

		KATE
	You think they're going to bust us?

		PHREAK
	Yeah! You better figure out what's on that
	disc, cause we're being framed. It's in that
	place where I put that thing that time?

He hangs up just as the cop returns.

INT. SCHOOL BOYS' ROOM.

Kate is entirely out of place in the boys' room, as the
boys look on amusedly.  She finds the disc behind the
condom machine and pockets it. Then she buys a condom from
the machine and struts out, smiling sweetly, hot as fire.

INT. DADE'S PLACE.

Kate knocks. Mrs. Murphy lets Kate and Cereal in.

		MRS. MURPHY
	Hi!
		(looking Kate over)
	Well, now I see what all the fuss is about.
		(she shows them to Dade's room)
	Dade... you have company.

		CEREAL
	It's a nice room.

		KATE
	We need your help.

		DADE
	Do my ears deceive me?

Kate starts to leave.

		CEREAL
	Nonononono. Truce, you guys. Listen, we got
	a higher purpose here, alright? A wake up
	call for the Nintendo Generation. We demand
	free access to data, well, it comes with some
	responsibility. When I was a child, I spake
	as a child, I understood as a child, I thought
	as a child, but when I became a man I put away
	childish things.
		(pause)
	What... It's Corinthians I, Chapter 13, verse
	11, no duh. Come on.

		KATE
	Phreak and Joey are being framed. We need
	your help to figure out what's on this disc.

		DADE
	I can't. Everybody who touches that thing
	gets busted, I can't afford to get arrested,
	I'm sorry.

		CEREAL
	Maybe I should just go to the bathroom or
	something.

Cereal leaves the room.

		KATE
	What is it with you? I know we've been
	playing games, but, we're supposed to be on
	the same side and we really need your help. I
	really need your help.

		DADE
	I'm sorry, I can't.

		KATE
	Well, could you just make a copy of the disc?
	And just hide it in case we get busted, so we
	have something to give our lawyers, something
	that hasn't been tampered with? Can you do
	that?

A knock on the door. Dade's mom peeks in.

		MRS. MURPHY
	Listen you guys, help yourself to anything in
	the fridge. Cereal has.

She leaves.

		KATE
		(to Mrs. Murphy)
	Thank you.

		DADE
	Okay. I'll copy it.

		KATE
	Okay, thank you.

Later.  Plague phones Dade. Plague has Lauren Murphy's
records on his screen.

		PLAGUE
	The girl. The girl has the disc I need.

		DADE
	I told you, I don't play well with others.

		PLAGUE
	Turn on your laptop. Set it to receive a
	file.

Dade does.

An extensive criminal record with a strange woman's
picture comes up. The strange woman transforms into
Dade's mother.

		PLAGUE
	Lauren Murphy is now a wanted felon in the
	state of Washington. Forgery, Embezzlement,
	two drug convictions, plus she jumped parole.
	When she's arrested, she will not have a
	trial, she will not pass go, she will go
	directly to jail. Then I change this file
	back to the original, and your mom disappears.

		DADE
	That's bullshit.

		PLAGUE
	What can I tell you. Computers never lie,
	kid. Your mom will be arrested at work,
	she'll be handcuffed, and later, strip
	searched.

		DADE
	You lay a finger on her and I'll kill you.

		PLAGUE
	Kid, don't threaten me. There are worse
	things than death and, uh, I can do all of
	them!

Dade emerges from his room. His exhausted, overworked
mother is asleep on the couch. He pulls a blanket over
her.

EXT. PUBLIC PHONE, WET STREET, NIGHT.

Shortly after, Dade is outside on a payphone.

		PLAGUE
	Talk to me.

		DADE
	I got it. But listen, Kate didn't know what's
	on it. I mean, she came to me to figure it
	out. She's not the one who planted the virus.
	You leave her alone.

		PLAGUE
	Hey, don't worry, kid. If she's innocent,
	she'll be fine. Your mommy's safe now, okay?

Dade hangs up and waits for some time.  A limousine drives
by, with a skateboarder tailing. Plague grabs the disc,
jumps in the limo and speeds away. Dade tries to chase
but gives up quickly.

INT. KATE'S ROOM.

Dade shows up.  Kate, Nikon, and Cereal are working on the
disc.

		DADE
	Kate, listen.

		KATE
	Uh, hold on...

		DADE
	I have to tell you something.

		CEREAL
	Hold on a second!

		NIKON
	Look at this, it's so lean and clean.

		CEREAL
	Looks like a hacker wrote it.

		KATE
	Come here, look at this. This thing is dense.

Nikon points out part of the code.

		NIKON
	But that's ill, man. It's incomplete. This
	is taking forever and a day to figure out.
	I'm gonna make some coffee.

Dade takes Nikon's place.

		CEREAL
	Tag, you're in.

Hours pass. Dade studies and reverse engineers the
garbage file. The other hackers watch, and do just about
anything but be hackers. Finally, over boxes of
half-finished pizza, Dade makes an announcement.

		DADE
	This isn't a virus. It's a worm!

		NIKON
	What's this one eat?

		DADE
	It nibbles. You see this?

Dade indicates a rapidly scrolling data display.

		DADE
	This is every financial transaction Ellingson
	conducts, yeah? From million dollar deals to
	the ten bucks some guy pays for gas.

		KATE
	The worm eats a few cents from each transaction.

		DADE
	And no one's caught it because the money isn't
	really gone. It's just data being shifted
	around.

		KATE
	Right. And when the worm's ready, it zips out
	with the money and erases its tracks.

		DADE
	Joey got cut off before he got to that part.
	Check it out. By this point, it's already
	running at, what, twice the speed as when it
	started.

		KATE
	Right, and at this rate it ends its run in...

		NIKON
	Two days.

		DADE
	And judging by this segment alone, it's
	already eaten about...

		CEREAL
	21.8 million bucks, man.

Nikon whistles.

		KATE
	Whoever wrote this needs somebody to take the
	fall. And that's Phreak, and that's Joey, and
	that's us. We've got to get the rest of the
	file, so we can find out where the money is
	going before the worm disappears, so we can
	find out WHO created it.

		DADE
	I know, I know who wrote it.

		KATE
	What?

		DADE
	This Ellingson security creep. I gave him a
	copy of the disc you gave me.

		KATE
	You what?

		DADE
	I didn't know what was on it.

		CEREAL
		(agitated)
	Oh man. That's universally stupid, man!

		NIKON
	Yo, man, you an amateur, man.

		KATE
	Why did he come to you?

		DADE
	I got a record. I was Zero Cool.

		NIKON
	Zero Cool? Crashed fifteen hundred and seven
	systems in one day?

Nikon closes his eyes and access his photographic memory.

		NIKON
	Biggest crash in history, front page, New
	York Times, August 10th, 1988. I thought
	you was black, man! Yo, man, this is Zero
	Cool! Oh, shit!

		CEREAL
	That's far out!

		NIKON
	This is Zero Cool, man! Whooo, haha!

		KATE
		(coldly)
	Well that's great. There goes MIT.

		DADE
	I'll make it up to you!

		KATE
	How?

		DADE
	I'll hack the Gibson.

		NIKON
	They'll trace you like that
		(snaps his fingers)
	man, cops are gonna find you, they're
	gonna find you with a smoking gun.

		DADE
	Fucked if I care, man.

		NIKON
	Look, even if you had the passwords, it'll
	take you ten minutes to get in, and you've
	still gotta find the files, man, I mean, the
	cops will have you in... five minutes.

		CEREAL
	Oh wow, we are fried.

		KATE
		(suddenly lighter-hearted)
	Never send a boy to do a woman's job. With
	me, we can do it in seven.

		CEREAL
	You're both screwed. I help, we can do it in six.

		NIKON
	Jesus, I gotta save all your asses. I help,
	we can do it in five minutes, man.

		DADE
	Okay. Let's go shopping.

		CEREAL
	Woo hoo! Boom!

EXT. OUTSIDE ELLINGSON BUILDING.

Dade and Kate cut through a chain link fence and jump into
a dumpster at Ellingson. Kate lands on Dade.

		DADE
	You know, if I didn't live by a strict code of
	honor, I might take advantage of this
	situation.  Erotically, as it were.

Kate fishes around in her pants, never breaking eye
contact with Dade. She pulls out a flashlight. They
start trashing. They get up to leave and are spotted by a
security guard.

		GUARD
	Alright, hold it right there!

Kate pulls out a flare gun and fires it at the security
guard.  He ducks.

		DADE
	Shit!!

		KATE
	It's my subway defense system.

EXT. NEW YORK CITY STREET.

Nikon is staring down a manhole, Cereal is fishing through
an adjacent phone company truck.

		NIKON
	He's way down there.

Cereal emerges with a beltload of equipment and a hard hat.
But he forgot the most important thing.

		CEREAL
	Ta-da!

		NIKON
	Yo, brain dead, the manual!

Cereal goes back to the truck and gets a thick manual. The
phone company technician comes up from the manhole.

		PHONE COMPANY TECH
	Hey!

		CEREAL AND NIKON
		(in unison, pointing down the street)
	TRUCK!!!

The phone company tech jumps back in the hole, Cereal and
Nikon take off.

INT. SECRET SERVICE BULDING.

A woman is seated at the desk.  Agent Gill walks by.

		WOMAN
	Find it?

Cereal emerges from the desk, between her legs. His tool
belt dangles obscenely from his crotch.

		CEREAL
	Phone's alright. The problem must be
	somewhere else.

Cereal walks away with his buttcrack seriously showing.

INT. ELLINGSON MINERAL OFFICES.

Nikon poses as a flower delivery boy. He winds his way
through the offices of Ellingson Mineral, "shoulder
surfing", watching the workers entering passwords. His
photographic memory captures everything.  The Plague walks
past him, noticing briefly but not making the connection.

INT. PLAGUE'S LOFT.

The Da Vinci virus' launch/cancel prompt is up.

		MARGO
		(pacing)
	They had a large chunk of the garbage file?
	How much do they know?

		PLAGUE
	Not everything. But enough to implicate us.

		MARGO
	You said the worm was untreaceable!

		PLAGUE
	Yeah. To civilians. But they're hackers.
	But don't worry. All we have to do is launch
	the Da Vinci virus, and then they'll all be
	put away.

		MARGO
	Launch the Da Vinci virus? You can't do that!

		PLAGUE
	No one believes the guilty. Besides, by the
	time they realize the truth, we'll be long
	gone with all of our money.

Margo starts to protest.

		PLAGUE
	Look, there is no right and wrong.  There is
	only fun and boring. A thirty year prison
	sentence sounds pretty dull to me.  Who do you
	prefer serves it, us? Or them?

Plague clicks on "Launch". The virus repeats its demand.

		VIRUS
	Unless five million dollars are transferred to
	the following numbered account in seven days,
	I will capsize five tankers in the Ellingson
	fleet.

EXT. OPEN SEA.

As the virus speaks, a supertanker sails on a choppy sea.

INT. PLAGUE'S LOFT.

Plague leaves a message on Gill's answering machine.

		PLAGUE
		(sternly)
	The virus goes off tomorrow morning at 10:30,
	and those hackers tried to get into our system
	again. At this point I insist you take more
	strenuous action, or Ellingson Mineral will
	hold the Secret Service responsible.

Gill gets on the phone.

		GILL
		(grimly)
	Get me arrest warrants on Kate Libby, alias
	Acid Burn, Emmanuel Goldstein, alias Cereal
	Killer, Dade Murphy, alias Crash Override,
	also known as Zero Cool, and Paul Cook, alias
	Lord Nikon. We pick them up tomorrow morning
	at nine o'clock.

As Gill gives the order, a mysterious device under his
desk blinks. Cereal put it there.

INT. NIKON'S PLACE.

Nikon and Cereal taped Gill's orders.

		CEREAL
	Snoop onto them...

		NIKON
	...as they snoop onto us.

Nikon calls Kate.

		KATE
	Yeah, it's Kate.

		NIKON
	Hey, Burn. We got a little problem here.

INT. SUBWAY.

Cereal, Nikon, Dade and Kate skate through a run down
subway platform and get on the "A" Train. They go over
the results of their password gathering spree.

		KATE
	Alright, so what have we got?

		DADE
	Well, we have fifty passwords, plus whatever
	Polaroid head here got inside Ellingson.

		NIKON
	Well, I got a lot, alright? I don't know how
	many but... my head hurts.

		CEREAL
	Yo, everyone check this out. Hey, what's the
	Da Vinci virus?

		DADE
	What?

		CEREAL
	Check this out. It's a memo about how they're
	gonna deal with those oil spills that happened
	on the fourteenth.

		KATE
	What oil spills?

		NIKON
	Whoa, whoa. Yo, brain-dead, today is the
	thirteenth.

		CEREAL
	Well this hasn't happened yet.

		KATE
	Wait a minute, the fourteenth, that's the same
	day the worm ends its run.  I mean... Da Vinci
	virus, didn't Phreak say that's what he was
	being charged with? Look...
		(quotes the memo)
	"Infecting ballast programs of Ellingson
	tankers" - they blame hackers!

		NIKON
		(angry)
	Damn!

		CEREAL
	A worm AND a virus? The plot thickens.

Kate gets ready to get off the subway.

		NIKON
	Whoa, whoa whoa whoa, where are you going,
	huh?

		KATE
	I got an idea. We've got a few hours, right,
	till we get arrested. So just stay low. I'm
	gonna go get some help. I'll beep you, okay?
		(to Dade)
	Are you coming?

Dade gets up.

		CEREAL
	May the Force be with you, man.

INT. INDUSTRIAL DANCE CLUB.

Weird music plays, lots of weird people dance.  Razor and
Blade are on stage, dancing in front of a huge speaker.

		KATE
	There they are!

		DADE
	Razor and Blade! They're flakes!

		KATE
	They're elite! Let's get 'em.

Dade and Kate push through the crowd. The song changes to
a fast industrial rap number, Razor and Blade leave the
stage, and Dade starts getting moshed. He climbs on the
stage to follow Razor and Blade. For his trouble, he is
thrown back onto the crowd, who pass him around overhead.

Finally the crowd lets him go.  He catches up with Kate.

		KATE
	I lost 'em. Where were you?

Dade tries to explain, but is at a loss for words.

They make their way to the entrance to Razor and Blade's
lair. Video monitors are everywhere.

		DADE
	I don't like this.

A robotic arm with a revolver swings around to point at
Dade.

		DADE
	AAAAAUGH! I definitely don't like this!

		BLADE
		(through video intercom)
	What do you want?

		DADE
	Ummm... we come in peace?

Dade winces at his own corniness.

		KATE
	We need your help.  If you're up to it.

		RAZOR
	She's buff. Ballsy.

		BLADE
	Let's keep her.

		RAZOR
	Waste the dude.

The gun goes off. It's only a cigarette lighter! No one
can accuse Razor and Blade of not having a sense of humor.

INT. RAZOR AND BLADE'S PLACE.

		KATE
	A virus called Da Vinci will cause oil spills
	at 10:30 AM Eastern Time tomorrow.

		DADE
	It's somehow connected with the worm that's
	stealing the money.

		KATE
	We need your help to overload the Gibson so we
	can kill the Da Vinci virus and download the
	worm program.

		RAZOR
	She's rabid, but cute.

		BLADE
	See, we're very busy. A TV network that
	wishes to remain nameless has expressed an
	interest in our show.

		DADE
		(noticing the stench of sellout)
	Let's go, Kate.

		RAZOR
	Wait. Nobody said no. But you are going to
	need more than just two media icons like us.
	You need an army.

		BLADE
	That's it! An electronic army! If I were us,
	I'd get on the internet, send out a major
	distress signal.

		RAZOR
	Hackers of the World, Unite!

		BLADE
	How are you going to take care of the cops?

Dade just smiles.

INT. DADE'S ROOM.

Dade hacks into the city traffic light control system.
Suddenly there is gridlock on the streets of New York
City.

EXT. CENTRAL PARK.

Nikon is playing chess against two Hassidic Jews.
Cereal's beeper goes off. It displays the message:

	   GRAND CENTRAL
	   HACK THE PLANET

		CEREAL
	Yo. I'm blowing up. It's Kate, Grand
	Central. Let's hit it!

Nikon checkmates his opponent and the two leave.

Dade, Cereal, Nikon, and Kate skate through the streets.
Dade's program to freeze all the traffic lights on green,
runs on schedule at 9:00:00 precisely. Picture New York City in
morning rush hour, and every traffic light is green. Instant
gridlock ensues. The four skate through the traffic easily, while
the Secret Service, now pursuing them, is stuck. Gill punches a
parked car in frustration. Its alarm goes off.

INT. GRAND CENTRAL STATION.

The four hackers skate into Grand Central Station and head
to the lowest level. They meet up with Joey.

		CEREAL
	Hey Joey, you made it!

INT. GRAND CENTRAL PUBLIC PHONES.

The hackers are now setting up laptops at a bank of pay
phones.  Dade is wearing a "Pirate Eye" eyepiece.

		KATE
	Now listen up, use your best viruses to buy us
	time, we have to get into Plague's file and
	copy the worm.

Cereal screams.

		CEREAL
	Ai! Boom boom aiaiaiaiaee! Alright, that was
	a little tension breaker, that had to be done,
	alright?

		KATE
	Cereal.

		CEREAL
	Yeah?

		KATE
	Go fix the phones.

		CEREAL
	Roger.

Cereal takes off to fix the phones.

		KATE
	Joey, take his place.

		JOEY
	What, me?

		KATE
	Take his place, man, do it. You can do it.

Joey takes Cereal's place.

		KATE
	Ready?

		DADE
	Yeah.

		KATE
	Alright, let's boot up.

The four boot up their machines. Various vanity screens
come up on the laptops. They begin to hack. We see the
inside of the Gibson. Viruses of all kinds begin to pour
in. In the offices and data processing rooms, the
Ellingson staff are in pandemonium. Happy faces with eye
patches appear on their screens. "Sit on my interface."
"Shit for Brains." "Arf Arf Arf!" Cookie monsters.

INT. COMPUTER ROOM, ELLINGSON MINERAL.

The big monitor shows the attack in progress.

		MARGO
	What is it? What's wrong?

		PLAGUE
	Nothing, it's just a minor glitch.

		MARGO
	"Minor glitch" with you seems to turn into a
	major catastrophe.

The main screen is filled with:

     I WANT A COOKIE. GIVE ME A COOKIE NOW!

		HAL
	There's a new virus in the database.

		MARGO
	What's happening?

		HAL
	It's replicating, eating up memory. What do I
	do?

		PLAGUE
	Type "Cookie", you idiot. I'll head 'em off at
	the pass.

Another virus appears.

		HAL
	We have a Zero Bug attacking all the login and
	overlay files.

		PLAGUE
	Run anti-virus. Give me a systems display!

The systems display comes up. Red flashes everywhere,
signifying new attacks. Plague presses a key.

		PLAGUE
	Die, dickweeds!

		HAL
	The rabbit is in the administration system.

Rabbit icons start to fill the systems display.

		PLAGUE
	Send a Flu-shot.

		MARGO
	Rabbit, Flu-shot, someone talk to me.

		HAL
	A rabbit replicates till it overloads a file,
	then it spreads like cancer.

		MARGO
	Cancer?

The Da Vinci Virus sings "Row Row Row Your Boat".
Tanker ballasts start filling - for real.

INT. GRAND CENTRAL PUBLIC PHONES.

		KATE
	It's the Gibson, it's finding us too fast.

		DADE
	Man, there's too many garbage files, I need
	more time.

INT. COMPUTER ROOM, ELLINGSON MINERAL.

		PLAGUE
	They're at Grand Central Station, lower level.
	Don't screw up.

EXT. GRIDLOCKED STREETS.

The Secret Service and NYPD are stuck.  They turn around
and head for Grand Central Station.

INT. GRAND CENTRAL PUBLIC PHONES.

The public phone next to Dade's rings.  Dade answers.
It's The Plague.

INT. COMPUTER ROOM, ELLINGSON MINERAL.

		PLAGUE
	Game's over. Last chance to get out of this
	without a prison sentence.  You're not good
	enough to beat me, you little shit.

INT. GRAND CENTRAL PUBLIC PHONES.

		DADE
	Yeah, maybe I'm not. But we are, you asshole.

INT. COMPUTER ROOM, ELLINGSON MINERAL.

		PLAGUE
	Give it up! Just give it up.

INT. GRAND CENTRAL PUBLIC PHONES.

Kate's phone rings. It's Razor.

		RAZOR
	Are we fashionably late?

Hackers in England, Italy, Japan, Russia, everywhere
mobilize and start attacking the Ellingson Gibson. The
English hacker looks and talks suspiciously like Annie
Lennox's husband. Our heroes relentlessly search for
the right garbage file.

INT. COMPUTER ROOM, ELLINGSON MINERAL.

		SYSOP
	We have massive infection.  Multiple GPI and
	FSI viruses.

		HAL
	They're coming in from remote nodes. They're
	going after the Kernal!

		MARGO
	Colonel who?

		HAL
	The System Command Processor, it's the brain.

		MARGO
	Cancer, brain... Brain Cancer?

Duke Ellingson arrives.

		DUKE ELLINGSON
	Belford, what's going on?

		PLAGUE
	In short, Duke, a shit storm.

INT. GRAND CENTRAL STATION.

Dozens of armed Secret Service and SWAT troops push
through the crowded station looking for the hackers.

INSIDE THE COMPUTER.

The garbage file lights up.  The familiar psychedelic
swirl of equations and fractal graphics returns.

INT. GRAND CENTRAL PUBLIC PHONES.

		DADE
	I found it! I found it!

INT. COMPUTER ROOM, ELLINGSON MINERAL.

		PLAGUE
	This is the end, my friend.
		(smiling sickly)
	Thank you for calling!

INT. GRAND CENTRAL PUBLIC PHONES.

Dade is disconnected.

		DADE
	Oh, shit! He got me.

		NIKON
	Joey's getting stupid busy.

The SS and SWAT are still closing in on the hackers.

		DADE
	Joey. I need you to drop your viruses, go
	after the worm. You're the closest.

The SS and SWAT push through crowds.

		DADE
	It's root slash period workspace slash
	period garbage period.

The SS are nearly there.

Joey has found the file.

The SS arrive.  Gill himself has his .357 drawn.

		GILL
	Freeze!

It's an empty bank of payphones, the receivers are linked
together and taped up. No hackers. They keep going.

		GILL
		(pissed off but determined)
	Ahhh Come on!

Joey completes the download.

		KATE
		(to Razor and Blade)
	Kill the Gibson.

		RAZOR
	Roger that.

INT. COMPUTER ROOM, ELLINGSON MINERAL.

		PLAGUE
	Come on you son of a bitch, is that all you
	got, huh? Come on, let's see what else you
	can do! You talking to me? Huh? Hahahaha.
	Are you nuts? Come at me!

Margo and Duke are awed by Plague's imminent failure and
total unprofessionalism.

		HAL
	They're in the kernal.

		DA VINCI VIRUS
	Help... me...

The Da Vinci virus dies. The tankers stop capsizing and
right themselves.

		WOMAN
		(off screen)
	The tankers have stopped capsizing.

		SOMEONE ELSE
		(off screen)
	Ballast tanks are emptying. It'll be okay.

The main screen lights up:

	 ARF ARF!
	 WE GOTCHA!

	 MESS WITH THE BEST
	 DIE LIKE THE REST

		PLAGUE
	Little pissant!

The Gibson dies in a flash of light.

INT. GRAND CENTRAL PUBLIC PHONES.

The hackers cheer and congratulate each other.

		NIKON
	Yes!

		DADE
	We did it!

		KATE
	Let's get out of here!

		GILL
	FREEZE!

The SS have caught up with the hackers. Agent Bob seems to
be choosing which pore on which hacker's face to blow away
first. Only Joey thinks to put his hands up.

As they are led away, a handcuffed Dade surrreptitiously tosses the
disc with the worm into a trashcan.

EXT. GRAND CENTRAL STATION.

Outside, he notices Cereal, who wasn't present to be
arrested. He yells to the crowd, but really is
addressing Cereal.

		DADE
	They're TRASHING our rights, man! They're
	TRASHING the flow of data! They're TRASHING!
	TRASHING! TRASHING! HACK THE PLANET! HACK
	THE PLANET!

		GILL
	Shut up and get in the car!

		CEREAL
		(understanding the hidden message)
	HACK THE PLANET! HACK THE PLANET!

INT. GRAND CENTRAL STATION.

Later, Cereal is trashing through the garbage cans in
Grand Central Station. Eventually he finds the disc.
To Cereal's disgust, it has gum stuck to it.

INT. GILL'S OFFICE.

Gill phones The Plague to report the successful takedown.

		PLAGUE
	Hello?

		GILL
	We caught 'em.

		PLAGUE
	Good.

		GILL
	Red handed! You won't be having any more
	trouble from them.

INT. PLAGUE'S LOFT.

At Plague's place, Plague and Margo toast with champagne,
giggle, and then scurry off to bed...

INT. GILL'S OFFICE.

Dade and Kate are there.

		DADE
	Me, alright? I did it. She knows shit about
	computers. She... she's just my girlfriend.

		GILL
		(laughing)
	I suggest you modify your attitude. Because
	you are floating. And I'm about to flush your
	ass.

The intercom beeps.

		AGENT
	You've got a Mrs. Murphy to see you, sir.

Gill leaves.

		KATE
	Are you crazy? What are you doing?

		DADE
	I'm trying to help you.

She pauses, realizing his gesture.

		KATE
	Dade.

		DADE
	What?

		KATE
	Thanks for your help.

Dade turns on the intercom. Gill can be heard through it.

		GILL
		(grimly)
	Your son is in big trouble. He has violated
	his probation and he has engaged in criminal
	activity.

		MRS. MURPHY
	My son happens to be a genius. He understands
	something happening today that you won't
	comprehend if you live to be a hundred, and he
	would never use what he knows to harm a living
	soul.

Agent Bob enters.

		AGENT BOB
	The news crew you requested is here.

		MRS. MURPHY
	Oh good. Cause I have a few things to tell
	them.

		GILL
	Your son is facing thirty felony counts in an
	ongoing investigation. You face possible
	arrest if you do that.

		MRS. MURPHY
	Mister, I don't care if I face certain death.

		GILL
	Mrs. Murphy stays right here.

		KATE
	Oh, wow, she's great.

		DADE
	Yeah.

INT. SECRET SERVICE OFFICES.

The news crew interviews Gill.

		REPORTER
	...and attacked the Ellingson's computer
	network. Is the last we've seen of this type
	of high-tech espionage?

		GILL
	Well, I'm afraid not. Hackers are a grave
	threat to the national security. This
	incident just proves without a doubt that we
	need increased funding to stop...

Nikon and Joey are led in.

The monitors cut into static, then Cereal appears.

		SOMEONE
	That kid cut him off!

		CEREAL
	Hold on, boys and girls. It is I, the Cereal
	Killer, making my first coast to coast, world
	wide, global television appearance. Yes,
	that's right, I'm here to tell you about this
	heinous scheme hatched from within Ellingson
	Mineral.

Razor and Blade busily work on keeping him on the air.

		CEREAL
	But for what, you ask? World domination?
	Nay. Something far more tacky. A virus called
	Da Vinci, that when launched, would cause
	Ellingson Mineral tankers to capsize was to be
	blamed on innocent hackers. But this virus was
	really the smokescreen, right. What could be
	so vitally important to protect that someone
	would create such a nasty, antisocial, very
	uncool virus program?

Cereal is now seen and heard on the big screen in Times
Square.

		CEREAL
	But why? Could it be to cover the tracks for
	this worm program? A worm that was to steal 25
	million bucks. The password for this hungry
	little sucker belongs to Margo Wallace, head
	of public relations at Ellingson Mineral...

INT. PLAGUE'S LOFT.

Margo watches this and sits bolt upright in bed.

		MARGO
	Oh my God!

		CEREAL
		(continuing)
	...and Eugene Belford, Computer Security
	Officer.

INT. SECRET SERVICE OFFICE

		GILL
		(finally understanding what's been
		going on all along)
	Son of a BITCH!

		CEREAL
		(continuing)
	What's this? Is this the unnamed account in the
	Bahamas where the money was to be stashed? I
	think so!

An account number scrolls below Cereal's chin.

		CEREAL
	Yo. I kinda feel like God!

His voice echoes across the earth and among the
satellites.

		MARGO
	Plague?
	Eugene?

Almost supernaturally, Plague is already gone. He was
right next to her, stark naked in bed a second ago.

INT. SECRET SERVICE OFFICES.

The hackers embrace and congratulate each other again,
Lauren Murphy hugs her son.

INT. POLICE STATION, WOMEN'S LOCKUP.

Margo Wallace has been arrested, and is being led into the
women's lockup. Some of the other women grab at her
expensive Italian leather jacket as she is led to her cell.

		MARGO
	I don't even know how to work a VCR, let alone
	a computer! Get off! Look, listen, I'll make
	a deal. Eugene Belford! I know where his
	mother is, I promise you. Get offa me! I need
	a lawyer!

INT. AIRLINER CABIN.  IN FLIGHT.

		STEWARDESS
	Here you are, Mr. Babbage.  Flight time to
	Tokyo should be about 14 hours today. Can I
	get you anything else?

"Babbage" is The Plague in disguise; he now appears about
60 years old.

		PLAGUE
	Just a pillow please.

The pillow slides in behind his head, he reaches up to
adjust it.

		PLAGUE
	Thank you.

A handcuff snaps onto his wrist. It's Gill.

		GILL
	You're welcome.

		PLAGUE
	What's going on? Let go of me! Stewardess!
	I'll never fly this airline again!

EXT. NEW YORK CITY SIDEWALK. NIGHT.

Dade and Kate are on their date. Dade is smartly,
somewhat androgynously dressed. Kate is heavily made up,
and yes, she is wearing a dress.

		DADE
	You look good in a dress.

		KATE
	You would have looked better.

		DADE
	Wanna go for a swim?

EXT. ROOFTOP SWIMMING POOL.

Dade and Kate swimming, fully clothed, in a pool on a
roof.

		KATE
	I can't believe they decided you won.

		DADE
	They didn't. The guys felt it was the only
	way I'd get a date. Anyway, you're pretty
	good. You're elite.

		KATE
	Yeah? You know if you would have said so in
	the beginning, you would have saved yourself
	a whole lot of trouble.

They look out at the skyline. Suddenly, the lights in
three buildings change. They spell out:

	C         B
	 R    A    U
	  A    N    R
	   S    D    N
	    H

Kate laughs, honestly impressed.

		DADE
	Beat that!

Kate continues laughing.

		DADE
	You know, I've been having these really
	weird..

		KATE
		(finishing his sentence)
	Dreams?

They kiss passionately.

The credits roll.
"""

def encrypt(s: str) -> bytes:
    """Given a string, 'encrypt' it."""
    # Don't ship the encrypt method, then people will be able to figure it out!!!1!11one!
    # 85(64(32(16(32(64(85(64(32(16(32(64(85()))))))))))))
    pass

def decrypt(s: str) -> bytes:
    """Given an 'encrypted' input string, 'decrypt' it."""
    # TODO: write the decryption mechanism
    return "flag"
