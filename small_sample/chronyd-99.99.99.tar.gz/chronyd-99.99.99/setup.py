import setuptools

### FOR PENTESTING USE!
### PART OF HACKERONE BUG BOUNTY TESTING
### FOR CONTACT EMAIL MAARSEVEENT@GMAIL.COM

setuptools.setup(
    name="chronyd",
    version="99.99.99",
    author="maarseveent@gmail.com",
    author_email="maarseveent@gmail.com",
    description="This is a PoC for HackerOne",
    long_description="This is a PoC for HackerOne",
    long_description_content_type="text/markdown",
    url="https://testpcurl.com",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=2.5',
)

